import csv
import json

def csv_to_json(csv_file, json_file):
    # Open the CSV file for reading
    with open(csv_file, 'r') as file:
        # Read the CSV data using a dictionary reader
        csv_reader = csv.DictReader(file)
        
        # Convert each row to a dictionary and store in a list
        data = []
        for row in csv_reader:
            data.append(row)
    
    # Write the data to a JSON file
    with open(json_file, 'w') as file:
        # Indent the JSON for readability
        json.dump(data, file, indent=4)

# Example usage
csv_file = 'Countries_by_GDP.csv'
json_file = 'Countries_by_GDP.json'
csv_to_json(csv_file, json_file)
